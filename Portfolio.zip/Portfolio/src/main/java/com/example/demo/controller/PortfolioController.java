package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Repository.PortfolioRepository;
import com.example.demo.entity.Portfolio;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/portfolio")
public class PortfolioController {

    @Autowired
    private PortfolioRepository portfolioRepository;

    // List all portfolios
    @GetMapping("/")
    public String listPortfolios(Model model) {
        // Fetch all portfolios from the repository (sorted by ID if necessary)
        List<Portfolio> portfolios = portfolioRepository.findAll();
        model.addAttribute("portfolios", portfolios);
        return "portfolio-list";
    }

    // Show form to create a new portfolio
    @GetMapping("/new")
    public String showCreateForm(Model model) {
        model.addAttribute("portfolio", new Portfolio());
        return "portfolio-form";
    }

    // Show form to edit an existing portfolio
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        Optional<Portfolio> portfolio = portfolioRepository.findById(id);
        if (portfolio.isPresent()) {
            model.addAttribute("portfolio", portfolio.get());
            return "portfolio-form";
        } else {
            return "redirect:/portfolio/";
        }
    }

    // Delete a portfolio
    @GetMapping("/delete/{id}")
    public String deletePortfolio(@PathVariable Long id) {
        portfolioRepository.deleteById(id);
        return "redirect:/portfolio/";
    }

    @PostMapping("/save")
    public String savePortfolio(@ModelAttribute Portfolio portfolio) {
        // Check if portfolio ID exists to determine if it's an update
        if (portfolio.getId() != null) {
            Optional<Portfolio> existingPortfolio = portfolioRepository.findById(portfolio.getId());
            if (existingPortfolio.isPresent()) {
                Portfolio updatedPortfolio = existingPortfolio.get();
                updatedPortfolio.setName(portfolio.getName());
                updatedPortfolio.setBio(portfolio.getBio());
                updatedPortfolio.setEducation(portfolio.getEducation());
                updatedPortfolio.setSkills(portfolio.getSkills());
                updatedPortfolio.setProjects(portfolio.getProjects());
                portfolioRepository.save(updatedPortfolio);
                return "redirect:/portfolio/";
            }
        }
        // Save new portfolio
        portfolioRepository.save(portfolio);
        return "redirect:/portfolio/";
    }
}
